const path =require('path'); 
const htmlWebpackplugin =require('html-webpack-plugin'); 
module.exports={
    entry: ['babel-polyfill','./src/js/index.js'],
    output:{
        path: path.resolve(__dirname, 'dist'),
        filename: 'js/bundle.js'
     },
    mode:'development',//this will not optimaz (for production it willl give optimaz repo)
    devServer:{
        contentBase: './dist',
    },
    plugins:[
        new htmlWebpackplugin({
            filename:'index.html',
            template:'./src/index.html'
        })
    ],
    module:{
        rules:[{
            test:/\.js/,//regEx for all .js file will taken
            exclude:/node_modules/,
            use:{
             loader:'babel-loader'           
            }

        }]
    }
}
//Four Main Cor in webpack is entry point ,output and loader and plugin