import axios from 'axios';
import { apiKey } from '../config';


export default class Recipe {
    constructor(id) {
        this.id = id;
    }
    async getRecipe() {
        try {
            const res = await axios(`https://api.spoonacular.com/recipes/${this.id}/information?includeNutrition=true&apiKey=${apiKey}`)
            this.title = res.data.title;
            this.authors = res.data.creditsText;
            this.image = res.data.image;
            this.url = res.data.sourceUrl;
            this.ingredients = res.data.extendedIngredients;
            this.serving = res.data.servings;
            this.readyTime = res.data.readyInMinutes;
        }
        catch (error) {
            alert('Something went wrong :(')
        }
    }
    // calMin() {
    //     //assumation for 15 each for 3 intgredient
    //     const numIngredent = this.ingredients.length;
    //     const periods = Math.ceil(numIngredent / 3);
    //     this.time = periods * 15
    // }
    // calServ() {

    //     this.Ser = 4;
    // }
    updateServing(type) {
        //update Serving
        const newServing = type == 'dec' ? this.serving - 1 : this.serving + 1;

        //update Ingredient
        this.ingredients.forEach(el => {            
            el.amount *= (newServing / this.serving)

        });
        this.serving = newServing

    }
}
