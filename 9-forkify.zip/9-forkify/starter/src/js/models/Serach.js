// export default 'I am Using String'
//=========================================================================================================
import axios from 'axios'
export default class Search {
    constructor(query) {
        this.query = query;
    }
    async getResult() {
        const apiKey = '772bd3dc7e6f4b8ba4e7a02e8acbe978';
        try {

            const res = await axios(`https://api.spoonacular.com/recipes/search?apiKey=${apiKey}&q=${this.query}`)
            this. result = await res.data
           // console.log(this.result)

        }
        catch{
            err => {
                console.log('ERROR!!!!!');

            }
        }

    }

}