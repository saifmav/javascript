import shortid from 'shortid'
export default class List{
    constructor(){
        this.items =[];
       // console.log(this.items,"==========list====");
        
    }
    addItem(amount,unit,ingredients){
        const item ={
            id:shortid.generate(),
            amount,
            unit,
            ingredients,
        } 
        this.items.push(item);
        return item;
    }
    deletitem(id){
        const index = this.items.findIndex(el=>el.id===id);
        
        //[1,2,3].splice (1,2)-->return [2,3] array[1] it use mutation(delet) for more example mdn
        //[1,2].slice(1,2)--->return 2 and array[1,2]
        this.items.splice(index,1)
    }
    
    updateAmount(id,newAmount){
        this.items.find(el=>el.id === id).amount = newAmount
    }
        
    
}