export default class likes{
    constructor(){
        this.likes=[];         
        
    }
    addLikes(id,title,authors,image){
        const like={
            id,
            title,
            authors,
            image
        };
        this.likes.push(like);
        //persist the data from loal Stroge
        this.parsistData()
        return like;
     };
     deletLike(id){
        const index = this.likes.findIndex(el=>el.id===id);        
        //[1,2,3].splice (1,2)-->return [2,3] array[1] it use mutation(delet) for more example mdn
        //[1,2].slice(1,2)--->return 2 and array[1,2]
        this.likes.splice(index,1);
        //parsist data from localStroge
        this.parsistData()

     };
     isLiked(id){
         return this.likes.findIndex(el=>el.id===id) !==-1;
     };
     getNumLikes(){
        return this.likes.length;
     };

     parsistData(){
         localStorage.setItem('likes',JSON.stringify( this.likes));
     }
    renderStorage(){
        const stroage =JSON.parse( localStorage.getItem('likes'))
        //restoring likes from localStorage
        if(stroage) this.likes = stroage;
    }
     
}