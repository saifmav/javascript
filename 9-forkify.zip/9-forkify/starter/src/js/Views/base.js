export const element={
 searchInput:document.querySelector('.search__field'),
 searchForm:document.querySelector('.search'),
 searchList:document.querySelector('.results__list'),
 searchRes:document.querySelector('.results'),
 searchPageRes:document.querySelector('.results__pages'),
 recipes:document.querySelector('.recipe'),
 shopping:document.querySelector('.shopping__list'),
 likemeun:document.querySelector('.likes__field'),
 likelist:document.querySelector('.likes__list')
 
};
export const ElementString={
    loader:'loader'
}

export const renderLoader=parent=>{
    const loader =`
    <div class="${ElementString.loader}">
        <svg>
        <use href="img/icons.svg#icon-cw"></use>
        </svg>
    </div>
    `;
    parent.insertAdjacentHTML('afterbegin',loader);
}

export const clearLoader=()=>{
    const load = document.querySelector(`.${ElementString.loader}`)
    if(load)
    load.parentElement.removeChild(load)
}