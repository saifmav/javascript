// export const add =(a,b)=>a+b;
// export const mult =(a,b)=>a*b;
// export const Id = 34;
//===================================================================================================================
import { element } from './base'
export const getInput = () => element.searchInput.value
export const clearInput = () => {
    element.searchInput.value = ' ';
}
export const clearResult = () => {
    element.searchList.innerHTML = ' ';
    element.searchPageRes.innerHTML=' ';
}
export const HighlightSelect =id=>{
    const arrRes = Array.from(document.querySelectorAll('.results__link'))
    arrRes.forEach(el=>{el.classList.remove('results__link--active')});

    document.querySelector(`.results__link[href*="#${id}"]`).classList.add('results__link--active')
}
export const TitleShort = (title, limit = 15) => {
    const newTitle = [];
    if (title.length > limit) {
        title.split(' ').reduce((acc, cur) => {
            if (acc + cur.length <= limit) {
                newTitle.push(cur)
            }
            return acc + cur.length;

        }, 0);
        return `${newTitle.join(' ')}.....`;
    }
    return title
};  

const renderRecipe = (recipe, baseUri) => {
    const markup = `
             <li>
                 <a class="results__link" href="#${recipe.id}">
                        <figure class="results__fig">
                            <img src="${baseUri + recipe.image}" alt="${recipe.title}"/>
                        </figure>
                        <div class="results__data">
                            <h4 class="results__name">${TitleShort(recipe.title)}</h4>
                         <p class="results__author">${recipe,"cheif Saif"}</p>
                        </div>
                 </a>
            </li>
    `;
    element.searchList.insertAdjacentHTML('beforeend', markup);
};
//Type 'next' or 'prev'
const ResderRes =(page,type)=>`
<button class="btn-inline results__btn--${type}" data-goto=${type==='prev'?page - 1 : page + 1}>
     <span>Page ${type=='prev'?page - 1 : page + 1}</span>
     <svg class="search__icon"><use href="img/icons.svg#icon-triangle-${type==='prev'? 'left' : 'right'}"></use> </svg>
</button> 
`;

const RendertButton= (page,numRes,resPerPage) =>{
    let button    
   const pages =Math.ceil(numRes/resPerPage)
   if(page===1 && pages > 1){
       //only next btn
       button = ResderRes(page,'next')
   }
   else if(page < pages){
       //both btn
       button=`
        ${ResderRes(page,'prev')}
        ${ResderRes(page,'next')}
       `
   }
   else if(page===pages && pages> 1){
       //only prev btn
       button = ResderRes(page,'prev')

   }

    element.searchPageRes.insertAdjacentHTML('afterbegin',button)
}
    


export const renderResult = (recipes,page=1,resPerPage=5) => {
    //reneder result current page
    const start = (page-1)*resPerPage;
    const end = page*resPerPage
    recipes.results.slice(start,end).forEach((data) => {
        renderRecipe(data, recipes.baseUri)          
    })
         //render result of pagination
         RendertButton(page,recipes.results.length,resPerPage)
     
};
