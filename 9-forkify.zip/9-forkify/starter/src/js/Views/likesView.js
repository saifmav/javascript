import {element} from './base'
import {TitleShort} from './searchView'
export const toggleBtn=isLiked =>{
    const iconString = isLiked ? 'icon-heart' : 'icon-heart-outlined';
    document.querySelector('.recipe__love use').setAttribute('href',`img/icons.svg#${iconString}`)
}
export const toggleLike = numLike =>{    
    element.likemeun.style.visibility =(numLike > 0) ? 'visible':'hidden';
}
export const renderLikes = like =>{
    const markup =
    `<li>
    <a class="likes__link" href="#${like.id}">
        <figure class="likes__fig">
            <img src="${like.image}" alt="Test">
        </figure>
        <div class="likes__data">
            <h4 class="likes__name">${TitleShort(like.title)}</h4>
            <p class="likes__author">${like.authors}</p>
        </div>
    </a>
</li>

    `;
    element.likelist.insertAdjacentHTML('beforeend',markup)
}
export const DeletList = id =>{
    const el = document.querySelector(`.likes__link[href*='${id}']`).parentElement;
     if(el) el.parentElement.removeChild(el)
}