// import str from './models/Serach';
//  import {add,mult,Id} from './Views/searchView'; // import Multple exports function using this way
// import * as maths from './Views/searchView';//another way doing multiple export fuction * is used



//  console.log(`using import function ${maths.add(10,20)} and ${maths.mult(maths.Id,1)} and ${str} `);
//======================================================================================================================================
import Search from "./models/Serach"
import * as searchView from './Views/searchView'
import * as RecipView from './Views/RecipeView'
import * as ListView from "./Views/ListView"
import * as likesView from "./Views/likesView"
import List from "./models/List"
import Recipe from "./models/Recipe"
import likes from "./models/likes"
import { element, renderLoader, clearLoader } from "./Views/base"

/** Global state
 * Search Object
 * current recipe Object
 * shopping List Object
 * likes recipes
 */
const state = {}
window.state = state
/*
Search Controller
*/
const controllSearch = async () => {
    //1)Get query from View
    const query = searchView.getInput()//Todo
    if (query) {
        //2)New Search object and add to state
        state.search = new Search(query)

        //3)Prepare Ui for result
        searchView.clearInput();
        searchView.clearResult();
        renderLoader(element.searchRes)
        try {

            //4)search for Recipe
            await state.search.getResult()
            //5)reander the results
            clearLoader();
            searchView.renderResult(state.search.result)
        } catch (error) {
            alert('Somthing went wrong on Search....')
            clearLoader()
        }
    }
}
element.searchForm.addEventListener('submit', e => {
    e.preventDefault();
    controllSearch();
})


element.searchPageRes.addEventListener('click', e => {
    const btn = e.target.closest('.btn-inline')
    if (btn) {
        const gotoPage = parseInt(btn.dataset.goto, 8);
        searchView.clearResult();
        searchView.renderResult(state.search.result, gotoPage)

    }

})

/*
Recipe Controller
*/
const ControllerRecipe = async () => {
    const id = window.location.hash.replace('#', '');
    if (id) {
        //prepare for Ui
        RecipView.clearRecipe();
        renderLoader(element.recipes)

        //highlight select
        if (state.search) {
            searchView.HighlightSelect(id)
        }
        //create new recipe object
        state.recipes = new Recipe(id);
        try {

            //get recipe
            await state.recipes.getRecipe();

            //calcu time and serving
           // state.recipes.calMin();
            //state.recipes.calServ();

            //redering recipe
            clearLoader()
            RecipView.renderRecipe(state.recipes, state.like.isLiked(id))

        }
        catch (error) {
            alert('Error on Processing recipe...:(')
        }
    }

}
//multiple event can be handle by this
const array = ['hashchange', 'load']
array.forEach(event => window.addEventListener(event, ControllerRecipe));

/*
List Controller
*/
const ControList = () => {
    //create list if none yet
    if (!state.list)
        state.list = new List()

    //add ingredient to list and ui
    state.recipes.ingredients.forEach(el => {
        const item = state.list.addItem(el.amount, el.unit, el.originalName)
        ListView.renderItem(item)
    })
}

//handle Delet and update list (even deligation)
element.shopping.addEventListener('click', e => {
    const id = e.target.closest('.shopping__item').getAttribute("data-itemid");
    //handle delet item
    if (e.target.matches('.shopping__delete, .shopping__delete *')) {
        //delet from state
        state.list.deletitem(id)

        //delet from ui
        ListView.DeleteItem(id)

        //handle the update count
    } else if (e.target.matches('.shopping__count--value')) {
        const val = parseFloat(e.target.value, 10);
        //add ingredients Shopping list
        if (val > 0) {

            state.list.updateAmount(id, val)
        }
    }
})

/*
Like Controller
*/
const ControlLike = () => {
    if (!state.like) state.like = new likes()
    const currentId = state.recipes.id;
    //user Yet Not added liked recipe
    if (!state.like.isLiked(currentId)) {

        //add  likes to state
        const newLike = state.like.addLikes(
            currentId,
            state.recipes.title,
            state.recipes.authors,
            state.recipes.image
        )
        //toggle like button
        likesView.toggleBtn(true)

        //Render in ui
        likesView.renderLikes(newLike)
    } else {

        //remove  likes to state
        state.like.deletLike(currentId)
        //toggle like button
        likesView.toggleBtn(false)
        //remove from ui
        likesView.DeletList(currentId)
    }
    likesView.toggleLike(state.like.getNumLikes());

}

//Restoring likes recipe on page load
window.addEventListener('load' ,()=>{
    state.like = new likes()
    //restoring like
    state.like.renderStorage()

    //toggle like menu
    likesView.toggleLike(state.like.getNumLikes());

    //rendeing restore like...
    state.like.likes.forEach(like=>likesView.renderLikes(like))
    
})

//handle recipe button(even Deligation)

element.recipes.addEventListener('click', el => {
    if (el.target.matches('.btn-dec,.btn-dec *')) {

        if (state.recipes.serving > 1) {

            state.recipes.updateServing('dec');
            RecipView.UpdateServingIng(state.recipes);

        }
    } else if (el.target.matches('.btn-inc,.btn-inc *')) {
        state.recipes.updateServing('inc')
        RecipView.UpdateServingIng(state.recipes);

    } else if (el.target.matches('.recipe_btn--add,.recipe_btn--add *')) {
        ControList()
    } else if (el.target.matches('.recipe__love, .recipe__love *')) {
        ControlLike()
    }


})
 //window.l= new List();

